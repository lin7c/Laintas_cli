#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="/usr/local/bin/laintas-cli"

if [ ! -x "$SCRIPT_DIR/laintas-cli" ]; then
  echo "Missing binary: $SCRIPT_DIR/laintas-cli"
  exit 1
fi

if [ "$(id -u)" -eq 0 ]; then
  install -m 755 "$SCRIPT_DIR/laintas-cli" "$TARGET"
else
  sudo install -m 755 "$SCRIPT_DIR/laintas-cli" "$TARGET"
fi

echo "Installed to $TARGET"
echo "Run: laintas-cli"
