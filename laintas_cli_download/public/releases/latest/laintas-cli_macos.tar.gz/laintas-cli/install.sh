#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/usr/local/lib/laintas_cli"
BIN_PATH="/usr/local/bin/laintas-cli"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required"
  exit 1
fi

if [ "$(id -u)" -eq 0 ]; then
  mkdir -p "$INSTALL_DIR"
  cp "$SCRIPT_DIR"/*.py "$INSTALL_DIR/"
  cp "$SCRIPT_DIR"/requirements.txt "$INSTALL_DIR/"
  cat > "$BIN_PATH" <<'LAUNCHER'
#!/usr/bin/env bash
exec python3 /usr/local/lib/laintas_cli/laintas_cli.py "$@"
LAUNCHER
  chmod 755 "$BIN_PATH"
else
  sudo mkdir -p "$INSTALL_DIR"
  sudo cp "$SCRIPT_DIR"/*.py "$INSTALL_DIR/"
  sudo cp "$SCRIPT_DIR"/requirements.txt "$INSTALL_DIR/"
  printf '%s\n' '#!/usr/bin/env bash' 'exec python3 /usr/local/lib/laintas_cli/laintas_cli.py "$@"' | sudo tee "$BIN_PATH" >/dev/null
  sudo chmod 755 "$BIN_PATH"
fi

python3 -m pip install -r "$SCRIPT_DIR/requirements.txt"

echo "Installed to $BIN_PATH"
echo "Run: laintas-cli"
