#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="/usr/local/lib/laintas_cli"

sudo mkdir -p "$INSTALL_DIR"
for f in "$SCRIPT_DIR"/*.py "$SCRIPT_DIR/requirements.txt"; do
  sudo cp "$f" "$INSTALL_DIR/"
done

sudo tee /usr/local/bin/laintas-cli > /dev/null << 'LAUNCHER'
#!/usr/bin/env bash
PYTHON3=$(command -v python3 || echo "")
[ -z "$PYTHON3" ] && { echo "ERROR: python3 not found. brew install python3"; exit 1; }
[ ! -d "$HOME/laintas_workspace" ] && mkdir -p "$HOME/laintas_workspace"
cd "$HOME/laintas_workspace"
exec "$PYTHON3" /usr/local/lib/laintas_cli/laintas_cli.py "$@"
LAUNCHER
sudo chmod +x /usr/local/bin/laintas-cli

echo "Installing Python dependencies..."
pip3 install -r "$INSTALL_DIR/requirements.txt" --quiet 2>/dev/null || \
  python3 -m pip install -r "$INSTALL_DIR/requirements.txt" --quiet 2>/dev/null || \
  echo "  (run: pip3 install requests rich prompt_toolkit mcp)"
echo "Done! Run: laintas-cli"
