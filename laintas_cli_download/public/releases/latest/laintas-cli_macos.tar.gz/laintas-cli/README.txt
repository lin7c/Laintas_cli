Laintas CLI v0.1.1 — macOS (source)

REQUIREMENTS
  Python 3.10+    https://www.python.org/downloads/
  pip3            (comes with Python)

INSTALL (automated)
  chmod +x install.sh && ./install.sh

INSTALL (manual)
  pip3 install requests rich prompt_toolkit mcp
  python3 laintas_cli.py

RUN
  laintas-cli          # if installed via install.sh
  python3 laintas_cli.py   # run directly
