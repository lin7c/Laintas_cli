Laintas CLI v0.1.1 — Windows (source)

REQUIREMENTS
  Python 3.10+    https://www.python.org/downloads/
  (check "Add Python to PATH" during install)

QUICK START
  1. Double-click setup.bat
  2. Run: python laintas_cli.py

MANUAL INSTALL
  pip install requests rich prompt_toolkit mcp
  python laintas_cli.py

NOTE
  Interactive PTY sessions (vim, etc.) are not supported on Windows.
  All AI agent and shell features work normally.
