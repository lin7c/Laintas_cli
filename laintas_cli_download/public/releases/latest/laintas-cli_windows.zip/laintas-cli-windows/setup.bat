@echo off
chcp 65001 >/dev/null 2>&1
setlocal EnableDelayedExpansion

echo.
echo ===== Laintas CLI v0.1.1 Setup ==========================
echo.

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

where python >/dev/null 2>&1
if %ERRORLEVEL% neq 0 (
    echo [!] Python 3.10+ not found.
    echo     Download: https://www.python.org/downloads/
    pause & exit /b 1
)

echo [1/3] Installing Python dependencies...
pip install -r "%SCRIPT_DIR%\requirements.txt" --quiet
echo       Done.

echo [2/3] Creating workspace...
if not exist "%USERPROFILE%\laintas_workspace" mkdir "%USERPROFILE%\laintas_workspace"
echo       %USERPROFILE%\laintas_workspace

echo [3/3] Creating launcher (laintas.bat) in current folder...
(
echo @echo off
echo cd /d "%USERPROFILE%\laintas_workspace"
echo python "%SCRIPT_DIR%\laintas_cli.py" %%*
) > "%SCRIPT_DIR%\laintas.bat"
echo       laintas.bat created.

echo.
echo ===== Done =============================================
echo.
echo   Run from this folder:  laintas.bat
echo   Or:  python laintas_cli.py
echo.
pause
