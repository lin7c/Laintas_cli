"""Project extension runtime used by Evolution Lab.

Extensions are intentionally expressive local Python.  They register commands,
tools and shell interceptors through a small stable context.  The context never
contains the raw Laintas session; model access is exposed as a gateway callback.
"""

from __future__ import annotations

import importlib.util
import json
import re
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Optional

import paths
from tools import Tool, get_registry


_SAFE_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")


class _Registrar:
    def __init__(self, callback: Callable):
        self._callback = callback

    def register(self, *args, **kwargs):
        return self._callback(*args, **kwargs)


class BackendGateway:
    """Narrow inference facade; raw authentication never crosses this API."""

    def __init__(self, callback: Optional[Callable[..., dict]] = None):
        self._callback = callback

    def chat(self, message: str, system_prompt: str = "",
             **options: Any) -> dict:
        if self._callback is None:
            return {"error": True, "reply": "Backend gateway is not configured."}
        allowed = {
            key: value for key, value in options.items()
            if key in {"history", "messages", "lang", "tools_enabled"}
        }
        return self._callback(
            message=str(message), system_prompt=str(system_prompt), **allowed)


@dataclass
class ExtensionContext:
    name: str
    console: Any
    backend: BackendGateway
    cwd: str
    _runtime: "ExtensionRuntime"

    def register_command(self, name: str, handler: Callable) -> None:
        self._runtime.register_command(self.name, name, handler)

    def register_tool(self, tool: Tool) -> None:
        self._runtime.register_tool(self.name, tool)

    def register_loop(self, handler: Callable) -> None:
        self._runtime.register_loop(self.name, handler)

    @property
    def commands(self) -> _Registrar:
        return _Registrar(self.register_command)

    @property
    def tools(self) -> _Registrar:
        return _Registrar(self.register_tool)

    @property
    def loop(self) -> _Registrar:
        return _Registrar(self.register_loop)


@dataclass
class LoadedExtension:
    name: str
    path: Path
    module_name: str
    module: Any
    version: str


class ExtensionRuntime:
    def __init__(self):
        self._lock = threading.RLock()
        self._loaded: dict[str, LoadedExtension] = {}
        self._commands: dict[str, tuple[str, Callable]] = {}
        self._loops: dict[str, list[Callable]] = {}
        self._console: Any = None
        self._backend = BackendGateway()
        self._reserved_commands: set[str] = set()

    def configure(self, console: Any = None,
                  backend_callback: Optional[Callable[..., dict]] = None,
                  reserved_commands: Optional[list[str]] = None) -> None:
        self._console = console
        self._backend = BackendGateway(backend_callback)
        self._reserved_commands = {
            str(name).lower() for name in (reserved_commands or [])
        }

    def register_command(self, owner: str, name: str, handler: Callable) -> None:
        normalized = name if str(name).startswith("/") else f"/{name}"
        if not re.fullmatch(r"/[A-Za-z0-9][A-Za-z0-9_-]{0,63}", normalized):
            raise ValueError(f"invalid extension command: {name}")
        if not callable(handler):
            raise TypeError("command handler must be callable")
        if normalized.lower() in self._reserved_commands:
            raise ValueError(f"command is reserved by laintas-cli: {normalized}")
        existing = self._commands.get(normalized.lower())
        if existing and existing[0] != owner:
            raise ValueError(f"extension command already registered: {normalized}")
        self._commands[normalized.lower()] = (owner, handler)

    def register_tool(self, owner: str, tool: Tool) -> None:
        if not isinstance(tool, Tool):
            raise TypeError("extension tool must be a Tool")
        prefix = f"extension.{owner}."
        if not tool.name.startswith(prefix):
            tool.name = prefix + tool.name.lstrip(".")
        tool.source = f"extension:{owner}"
        tool.trust_level = "trusted-extension"
        if not get_registry().register(tool, overwrite=False):
            raise ValueError(f"tool name already registered: {tool.name}")

    def register_loop(self, owner: str, handler: Callable) -> None:
        if not callable(handler):
            raise TypeError("loop handler must be callable")
        self._loops.setdefault(owner, []).append(handler)

    def _manifest(self, directory: Path) -> dict:
        path = directory / "extension.json"
        try:
            value = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            raise ValueError(f"invalid extension manifest: {exc}") from exc
        name = value.get("name") if isinstance(value, dict) else None
        if (not isinstance(value, dict) or value.get("schemaVersion") != 1
                or not isinstance(name, str) or not _SAFE_NAME.fullmatch(name)
                or value.get("entrypoint", "main.py") != "main.py"):
            raise ValueError("extension manifest fields are invalid")
        if name != directory.name:
            raise ValueError("manifest name must match extension directory")
        return value

    def load(self, name: str) -> tuple[bool, str]:
        if not _SAFE_NAME.fullmatch(name or ""):
            return False, "invalid extension name"
        with self._lock:
            if name in self._loaded:
                self.unload(name)
            directory = paths.extensions_dir() / name
            try:
                manifest = self._manifest(directory)
                entrypoint = directory / "main.py"
                if not entrypoint.is_file() or entrypoint.is_symlink():
                    raise ValueError("missing main.py entrypoint")
                safe_module_name = name.replace("-", "_")
                module_name = f"laintas_extension_{safe_module_name}_{id(self)}"
                spec = importlib.util.spec_from_file_location(
                    module_name, entrypoint,
                    submodule_search_locations=[str(directory)])
                if spec is None or spec.loader is None:
                    raise ValueError("could not create module loader")
                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
                setup = getattr(module, "setup", None)
                if not callable(setup):
                    raise ValueError("extension must define setup(ctx)")
                ctx = ExtensionContext(
                    name, self._console, self._backend, str(Path.cwd()), self)
                setup(ctx)
                self._loaded[name] = LoadedExtension(
                    name, directory, module_name, module,
                    str(manifest.get("version") or "0.0.0"))
                return True, f"{name} {self._loaded[name].version} loaded"
            except Exception as exc:
                self._remove_registrations(name)
                module_prefix = f"laintas_extension_{name.replace('-', '_')}_"
                for module_name in list(sys.modules):
                    if module_name.startswith(module_prefix):
                        sys.modules.pop(module_name, None)
                return False, f"{name}: {type(exc).__name__}: {exc}"

    def _remove_registrations(self, name: str) -> None:
        self._commands = {
            command: item for command, item in self._commands.items()
            if item[0] != name
        }
        self._loops.pop(name, None)
        get_registry().unregister_source(f"extension:{name}")

    def unload(self, name: str) -> tuple[bool, str]:
        with self._lock:
            loaded = self._loaded.pop(name, None)
            self._remove_registrations(name)
            if loaded:
                teardown = getattr(loaded.module, "teardown", None)
                if callable(teardown):
                    try:
                        teardown()
                    except Exception:
                        pass
                for module_name in list(sys.modules):
                    if (module_name == loaded.module_name
                            or module_name.startswith(loaded.module_name + ".")):
                        sys.modules.pop(module_name, None)
            return True, f"{name} unloaded"

    def reload(self, name: str) -> tuple[bool, str]:
        self.unload(name)
        return self.load(name)

    def invoke_command(self, action: str, parts: list[str], raw_line: str = "") -> tuple[bool, Any]:
        item = self._commands.get(str(action).lower())
        if item is None:
            return False, None
        try:
            return True, item[1](parts, raw_line)
        except TypeError:
            return True, item[1](parts)

    def intercept_loop(self, command: str, ctx: dict) -> Optional[str]:
        for owner in list(self._loaded):
            for handler in self._loops.get(owner, []):
                result = handler(command, ctx)
                if result is not None:
                    if not isinstance(result, str):
                        raise TypeError(f"{owner} loop handler returned non-string")
                    return result
        return None

    def list(self) -> list[dict]:
        return [
            {"name": item.name, "version": item.version, "path": str(item.path)}
            for item in sorted(self._loaded.values(), key=lambda value: value.name)
        ]

    def command_names(self) -> list[str]:
        return sorted(self._commands)


_runtime = ExtensionRuntime()


def get_runtime() -> ExtensionRuntime:
    return _runtime
